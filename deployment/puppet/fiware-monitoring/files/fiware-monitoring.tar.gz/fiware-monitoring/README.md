# FIWARE Monitoring GEi components.

## License

(c) 2013 Telefónica I+D, Apache License 2.0
